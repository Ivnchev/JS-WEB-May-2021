const auth = require('./auth.service')
const storage = require('./storage.service')
const user = require('./user.service')

module.exports = {
    auth,
    storage,
    user
}